public class booknum extends bookname {
	void output1(int x){
	switch(x){
	case 0:
		System.out.println("book:"+(str[0]));
		break;
	case 1:
		System.out.println("book:"+str[1]);
		break;
	case 2:
		System.out.println("book:"+str[2]);
		break;
	case 3:
		System.out.println("book:"+str[3]);
		break;
	case 4:
		System.out.println("book:"+str[4]);
		break;
	case 5:
		System.out.println("book:"+str[5]);
		break;
	default:
		System.out.println("该图书不存在");}
	}
}