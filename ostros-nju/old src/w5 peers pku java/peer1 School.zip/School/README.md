# 选课系统功能介绍  
请运行./out/artifacts/School_jar/School.jar

### Administrator
1. 添加学生
2. 添加老师

### Teacher
1. 添加课程

### Student
1.选课