package me.singleneuron.person;

import me.singleneuron.Helper;

import java.math.BigInteger;
import java.security.MessageDigest;
import java.util.Scanner;

public abstract class User implements sayHalloAble {

    public String mName;
    public String mPassword;
    public Permission[] permissions = null;

    public String getName() {
        return mName;
    }

    public void sayHello() {
        System.out.println("Hello, " + mName + ".");
    }

    public boolean login(String password) {
        return mPassword.equals(getEncryptedString(password));
    }

    public void setPassword(String password) {
        String string = getEncryptedString(password);
        if (string!=null) mPassword = string;
    }

    public static String getEncryptedString(String origin) {
        try {
            MessageDigest messageDigest = MessageDigest.getInstance("MD5");
            messageDigest.reset();
            return new BigInteger(1,messageDigest.digest(origin.getBytes())).toString(16);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    public void setPassword() {
        try {
            Scanner scanner = Helper.scanner;
            String password = scanner.next();
            this.setPassword(password);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

}
