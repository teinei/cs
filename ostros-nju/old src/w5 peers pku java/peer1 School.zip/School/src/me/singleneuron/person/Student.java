package me.singleneuron.person;

import me.singleneuron.Course.Course;
import me.singleneuron.Helper;
import me.singleneuron.pool.PoolHelper;

import java.util.HashMap;
import java.util.Map;

public final class Student extends User {

    public HashMap<String,Course> coursePool = new HashMap<>();

    public Student() {
        permissions = new Permission[]{Permission.chooseCourse};
    }

    @Override
    public void sayHello() {
        System.out.println("Hello, " + mName + ". You're " + getClass().getSimpleName());
    }

    public void chooseCourse() {
        try {
            System.out.print("可以选择的课程有: ");
            for (Map.Entry<String, Course> entry : PoolHelper.CoursePool.entrySet()) {
                System.out.printf("%s\t%s\n", entry.getKey(), entry.getValue().teacher);
            }
            System.out.print("请输入要选择的课程: ");
            String name = Helper.scanner.next();
            if (!PoolHelper.CoursePool.containsKey(name)) System.out.println("课程不存在");
            Course course = PoolHelper.CoursePool.get(name);
            this.coursePool.put(name,course);
            Helper.sync(PoolHelper.StudentPool,"StudentPool");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void exit() {
        System.exit(0);
    }

    @Override
    public void sayHallo() {
        super.sayHello();
    }
}
