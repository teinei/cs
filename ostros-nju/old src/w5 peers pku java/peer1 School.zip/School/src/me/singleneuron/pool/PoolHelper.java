package me.singleneuron.pool;

import me.singleneuron.Course.Course;
import me.singleneuron.person.Administrator;
import me.singleneuron.person.Student;
import me.singleneuron.person.Teacher;
import me.singleneuron.person.User;

import java.util.HashMap;

public class PoolHelper {

    public static HashMap<String, Course> CoursePool = new HashMap<>();
    public static HashMap<String, Teacher> TeacherPool = new HashMap<>();
    public static HashMap<String, Student> StudentPool = new HashMap<>();
    public static Administrator administrator = null;

    public static User getUser(String name) {
        if (name.equals("Administrator")) return administrator;
        else if (TeacherPool.containsKey(name)) return TeacherPool.get(name);
        else if (StudentPool.containsKey(name)) return StudentPool.get(name);
        else return null;
    }

}
