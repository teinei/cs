package me.singleneuron.person;

public interface sayHalloAble {

    void sayHallo();

}
