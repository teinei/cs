package me.singleneuron;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import me.singleneuron.Course.Course;
import me.singleneuron.person.Administrator;
import me.singleneuron.person.Student;
import me.singleneuron.person.Teacher;
import me.singleneuron.person.User;
import me.singleneuron.pool.PoolHelper;

import java.io.File;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Scanner;

public class Main {

    public static void main(String[] args) {

        //初始化
        File configs = new File("./config");
        if (!configs.exists()) configs.mkdir();
        File adminConfig = new File("./config/Administrator.json");
        File teacherPool = new File("./config/TeacherPool.json");
        File studentPool = new File("./config/StudentPool.json");
        File coursePool = new File("./config/CoursePool.json");
        if (teacherPool.exists()) {
            PoolHelper.TeacherPool = new Gson().fromJson(Helper.readFile(teacherPool),  new TypeToken<HashMap<String, Teacher>>(){}.getType());
        }
        if (studentPool.exists()) {
            PoolHelper.StudentPool = new Gson().fromJson(Helper.readFile(studentPool),  new TypeToken<HashMap<String, Student>>(){}.getType());
        }
        if (coursePool.exists()) {
            PoolHelper.CoursePool = new Gson().fromJson(Helper.readFile(coursePool),  new TypeToken<HashMap<String, Course>>(){}.getType());
        }
        if (!adminConfig.exists()) {
            System.out.print("管理员账户不存在，正在新建...\n用户名:Administrator\n请输入密码:");
            PoolHelper.administrator = new Administrator();
            PoolHelper.administrator.setPassword();
        } else {
            String adminJson = Helper.readFile(adminConfig);
            PoolHelper.administrator = Administrator.fromJson(adminJson);
        }

        //登录
        User correctUser = null;
        try {
            Scanner scanner = Helper.scanner;
            System.out.print("请输入用户名: ");
            String username = scanner.next();
            correctUser = PoolHelper.getUser(username);
            if (correctUser==null) {
                System.out.println("用户不存在");
                return;
            }
            System.out.print("请输入密码: ");
            String password = scanner.next();
            boolean success = correctUser.login(password);
            if (!success) {
                System.out.println("密码错误");
                return;
            }
            System.out.println("登录成功");
            correctUser.sayHello();
        } catch (Exception e) {
            e.printStackTrace();
        }

        //菜单
        System.out.print("您的权限有：");
        System.out.println(Arrays.toString(correctUser.permissions));
        while (true) {
            try {

                System.out.print("请输入您的操作（输入exit退出）：");
                Scanner scanner = new Scanner(System.in);
                String method = scanner.next();
                correctUser.getClass().getDeclaredMethod(method).invoke(correctUser);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

    }
}
