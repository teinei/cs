package me.singleneuron;

import com.google.gson.GsonBuilder;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.lang.reflect.Type;
import java.util.Scanner;

public class Helper {

    public static Scanner scanner = new Scanner(System.in);

    public static void sync(Object object, String fileString) {
        File file = new File("./config/"+fileString+".json");
        String json = new GsonBuilder().setPrettyPrinting().create().toJson(object);
        writeFile(json,file);
    }

    public static String readFile(File file) {
        try(FileInputStream fileInputStream = new FileInputStream(file)) {
            byte[] filecontent = new byte[Long.valueOf(file.length()).intValue()];
            fileInputStream.read(filecontent);
            return new String(filecontent);
        } catch (Exception e){
            e.printStackTrace();
        }
        return "";
    }

    public static void writeFile(String string, File file) {
        try (BufferedWriter bufferedWriter = new BufferedWriter(new FileWriter(file));) {
            if (!file.exists()) file.createNewFile();
            bufferedWriter.write(string);
            bufferedWriter.flush();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

}
