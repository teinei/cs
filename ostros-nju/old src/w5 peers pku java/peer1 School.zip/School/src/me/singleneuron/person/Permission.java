package me.singleneuron.person;

public enum Permission {
    editStudent, editTeacher, editCourse, chooseCourse
}
