package me.singleneuron.person;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import me.singleneuron.Helper;
import me.singleneuron.pool.PoolHelper;

import java.io.File;
import java.util.Scanner;

public final class Administrator extends User {

    public Administrator() {
        mName = this.getClass().getSimpleName();
        permissions = new Permission[]{Permission.editStudent,Permission.editTeacher};
    }

    public void editStudent() {

        try {
            System.out.print("添加学生: ");
            String name = Helper.scanner.next();
            Student student = new Student();
            student.mName = name;
            student.setPassword("000000");
            PoolHelper.StudentPool.put(name,student);
            System.out.println("添加学生：" + name + "， 默认密码为000000");
            Helper.sync(PoolHelper.StudentPool,"StudentPool");
        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    public void editTeacher() {
        try {
            System.out.print("添加老师: ");
            String name = Helper.scanner.next();
            Teacher teacher = new Teacher();
            teacher.mName = name;
            teacher.setPassword("000000");
            PoolHelper.TeacherPool.put(name,teacher);
            System.out.println("添加老师：" + name + "， 默认密码为000000");
            Helper.sync(PoolHelper.TeacherPool,"TeacherPool");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static Administrator fromJson(String json) {
        return new Gson().fromJson(json, Administrator.class);
    }

    @Override
    public void setPassword(String password) {
        super.setPassword(password);
        Helper.sync(this, "Administrator");
    }

    public void exit() {
        System.exit(0);
    }

    @Override
    public void sayHallo() {
        super.sayHello();
    }
}
