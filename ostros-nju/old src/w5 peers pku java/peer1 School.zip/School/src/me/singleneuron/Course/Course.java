package me.singleneuron.Course;

public class Course {
    public String name;
    public String teacher;
}
