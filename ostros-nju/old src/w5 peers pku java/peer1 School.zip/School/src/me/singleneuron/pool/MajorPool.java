package me.singleneuron.pool;

public enum MajorPool {
    文学, 数学, 物理, 化学, 生物, 计算机
}
