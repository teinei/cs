package me.singleneuron.person;

import me.singleneuron.Course.Course;
import me.singleneuron.Helper;
import me.singleneuron.pool.PoolHelper;

public final class Teacher extends User {

    public Teacher() {
        permissions = new Permission[]{Permission.editCourse};
    }

    @Override
    public void sayHello() {
        System.out.println("Hello, " + mName + ". You're " + getClass().getSimpleName());
    }

    public void editCourse() {

        try {
            System.out.print("添加课程: ");
            String name = Helper.scanner.next();
            Course course = new Course();
            course.name = name;
            course.teacher = this.mName;
            PoolHelper.CoursePool.put(name,course);
            System.out.println("添加课程：" + name);
            Helper.sync(PoolHelper.CoursePool,"CoursePool");
        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    public void exit() {
        System.exit(0);
    }

    @Override
    public void sayHallo() {
        super.sayHello();
    }
}
